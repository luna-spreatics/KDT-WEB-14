import React from "react";

export default function MainPage() {
  return (
    <main>
      <h1>Home</h1>
    </main>
  );
}
